var itemsCount = 0;
var cartItems = [];
function initListeners() {
  $("#plus-btn").click(function (e) {
    let itemID = this.id;
    itemsCount++;
    // console lof shows it in the gooflge inspect//
    console.log(itemsCount);
    $(".items").html(itemsCount);
  });
  $("#minus-btn").click(function (e) {
    if (itemsCount != 0) {
    itemsCount--;
    console.log(itemsCount);
    $(".items").html(itemsCount);
  }
  });

$ (document).ready(function () {
  initListeners();
});
}

// use #plus-btn and 